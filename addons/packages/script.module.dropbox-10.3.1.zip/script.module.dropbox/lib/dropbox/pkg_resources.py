def resource_filename(package_or_requirement, resource_name):
    return resource_name